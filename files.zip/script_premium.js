/* ================================================
   SAMMY DIGITAL SERVICES - SCRIPT PREMIUM
   JavaScript Performant & Épuré
   ================================================ */

// ================================================
// 1.5 GESTION DES COOKIES - CORRIGÉ & FONCTIONNEL
// ================================================

function setupCookies() {
    console.log('🍪 Initialisation des cookies...');
    
    const banner = document.getElementById('cookiesBanner');
    const acceptBtn = document.getElementById('cookiesAccept');
    const rejectBtn = document.getElementById('cookiesReject');
    
    if (!banner) {
        console.warn('Bannière cookies non trouvée');
        return;
    }
    
    const cookieConsent = getCookie('sammy_cookies_consent');
    console.log('Cookie trouvé:', cookieConsent);
    
    // Afficher la bannière si pas de consentement
    if (!cookieConsent) {
        banner.style.display = 'flex';
        console.log('✓ Bannière affichée');
    } else {
        banner.style.display = 'none';
        console.log('✓ Bannière masquée (consentement trouvé)');
    }
    
    // Bouton Accepter
    if (acceptBtn) {
        acceptBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('👆 Clique sur Accepter');
            setCookie('sammy_cookies_consent', 'accepted', 365);
            initializeAnalytics();
            hideCookiesBanner();
            showMessage('✓ Merci pour votre consentement!', 'success');
        });
    }
    
    // Bouton Refuser
    if (rejectBtn) {
        rejectBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('👆 Clique sur Refuser');
            setCookie('sammy_cookies_consent', 'rejected', 365);
            hideCookiesBanner();
            showMessage('✓ Votre préférence a été enregistrée.', 'success');
        });
    }
}

function setCookie(name, value, days) {
    const expires = new Date();
    expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
    const expiresStr = expires.toUTCString();
    const cookieValue = `${name}=${value}; expires=${expiresStr}; path=/`;
    document.cookie = cookieValue;
    console.log('🍪 Cookie créé:', name, '=', value, '(', days, 'jours)');
}

function getCookie(name) {
    const nameEQ = name + '=';
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i].trim();
        if (cookie.indexOf(nameEQ) === 0) {
            return cookie.substring(nameEQ.length);
        }
    }
    console.log('❌ Cookie non trouvé:', name);
    return null;
}

function hideCookiesBanner() {
    const banner = document.getElementById('cookiesBanner');
    if (banner) {
        // Fade out et slide down
        banner.style.opacity = '0';
        banner.style.transform = 'translateY(20px)';
        banner.style.transition = 'all 0.4s ease-out';
        
        setTimeout(() => {
            banner.style.display = 'none';
            console.log('✓ Bannière masquée');
        }, 400);
    }
}

function initializeAnalytics() {
    console.log('📊 Analytics initialisé - Cookies acceptés');
    
    // Remplacez par votre code Google Analytics, Hotjar, etc.
    // Exemple avec Google Analytics:
    // if (window.gtag) {
    //     gtag('consent', 'update', {
    //         'analytics_storage': 'granted'
    //     });
    // }
}

// ================================================
// 2. THÈME SOMBRE/CLAIR
// ================================================

function setupTheme() {
    const themeToggle = document.querySelector('.theme-toggle');
    const savedTheme = localStorage.getItem('theme') || 'light';
    
    applyTheme(savedTheme);
    
    if (themeToggle) {
        themeToggle.addEventListener('click', (e) => {
            e.preventDefault();
            const newTheme = document.body.classList.contains('dark-mode') ? 'light' : 'dark';
            applyTheme(newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
}

function applyTheme(theme) {
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
}

// ================================================
// 3. NAVIGATION
// ================================================

function setupNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            updateToggleState(navToggle);
        });
        
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                navToggle.classList.remove('active');
            });
        });
    }
    
    // Fermer le menu au scroll
    window.addEventListener('scroll', () => {
        if (navMenu && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
        }
    });
}

function updateToggleState(toggle) {
    toggle.classList.toggle('active');
}

// ================================================
// 4. ANIMATIONS AUX NOMBRES (STATS)
// ================================================

function setupCountAnimation() {
    const counters = document.querySelectorAll('.stat-number[data-count]');
    
    if (counters.length === 0) return;
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
                animateCounter(entry.target);
                entry.target.classList.add('counted');
            }
        });
    }, { threshold: 0.5 });
    
    counters.forEach(counter => observer.observe(counter));
}

function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-count'));
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    let step = 0;
    
    const timer = setInterval(() => {
        current += increment;
        step++;
        
        if (step >= steps) {
            current = target;
            clearInterval(timer);
        }
        
        element.textContent = Math.floor(current);
    }, duration / steps);
}

// ================================================
// 5. VALIDATION FORMULAIRE
// ================================================

function setupFormValidation() {
    const form = document.getElementById('contactForm');
    
    if (!form) return;
    
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (!validateForm(form)) {
            showMessage('Veuillez remplir tous les champs correctement', 'error');
            return;
        }
        
        submitForm(form);
    });
}

function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    return Array.from(inputs).every(input => {
        if (input.type === 'email') {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value);
        }
        return input.value.trim().length > 0;
    });
}

function submitForm(form) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Envoi...';
    
    // Simuler un envoi (remplacer par une vraie API si nécessaire)
    setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
        form.reset();
        showMessage('Merci ! Nous vous recontacterons bientôt.', 'success');
    }, 1500);
}

function showMessage(text, type) {
    const message = document.createElement('div');
    message.className = `message message-${type}`;
    message.textContent = text;
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        border-radius: 4px;
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
        max-width: 400px;
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => message.remove(), 300);
    }, 3000);
}

// ================================================
// 6. SMOOTH SCROLL
// ================================================

function setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
            const href = anchor.getAttribute('href');
            if (href === '#') return;
            
            e.preventDefault();
            const target = document.querySelector(href);
            
            if (target) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = target.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ================================================
// 7. INTERSECTION OBSERVER - ANIMATIONS
// ================================================

function setupIntersectionObserver() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.6s ease-out forwards';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
    
    // Observer les éléments à animer
    document.querySelectorAll('.service, .portfolio-item, .pricing-card, .feature, .info-item').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
}

// ================================================
// 8. UTILITAIRES
// ================================================

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ================================================
// 9. PERFORMANCE MONITORING
// ================================================

if ('PerformanceObserver' in window) {
    try {
        const observer = new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                if (entry.entryType === 'paint') {
                    console.log(`${entry.name}: ${entry.startTime}ms`);
                }
            }
        });
        observer.observe({ entryTypes: ['paint'] });
    } catch (e) {
        // Navigateur non supporté
    }
}

// ================================================
// 10. LAZY LOADING IMAGES
// ================================================

if ('IntersectionObserver' in window && 'loading' in HTMLImageElement.prototype) {
    document.querySelectorAll('img[loading="lazy"]').forEach(img => {
        img.loading = 'lazy';
    });
} else {
    // Fallback pour les anciens navigateurs
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => imageObserver.observe(img));
}

// ================================================
// 11. GESTION DE LA CONNEXION
// ================================================

window.addEventListener('online', () => {
    console.log('Connexion rétablie');
});

window.addEventListener('offline', () => {
    console.log('Mode hors ligne');
});

// ================================================
// 12. ANIMATIONS CSS
// ================================================

const styles = document.createElement('style');
styles.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(20px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(20px);
        }
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .nav-menu.active {
        display: flex;
        flex-direction: column;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: inherit;
        padding: 1rem;
        gap: 0.5rem;
    }
    
    .nav-toggle.active .nav-toggle-line:nth-child(1) {
        transform: rotate(45deg) translate(8px, 8px);
    }
    
    .nav-toggle.active .nav-toggle-line:nth-child(2) {
        opacity: 0;
    }
`;

document.head.appendChild(styles);

// ================================================
// 13. CONSOLE MESSAGE
// ================================================

console.log('%c🚀 Sammy Digital Services', 'color: #FF6B35; font-size: 18px; font-weight: bold;');
console.log('%cSite professionnel - Performance optimisée', 'color: #666; font-size: 12px;');
